const crypto = require("crypto");
const path = require("path");
require("dotenv").config({ path: path.join(__dirname, ".env") });

const { Pool } = require("pg");

const poolConfig = {
  host: process.env.PGHOST || "localhost",
  port: Number(process.env.PGPORT || 5432),
  database: process.env.PGDATABASE || "worldcup",
  user: process.env.PGUSER || "postgres",

};
if (process.env.DATABASE_URL && !process.env.PGPASSWORD) {
  poolConfig.connectionString = process.env.DATABASE_URL;
}
poolConfig.password = process.env.PGPASSWORD;

const pool = new Pool(poolConfig);

const FieldValue = {
  serverTimestamp: () => ({ __op: "serverTimestamp" }),
  increment: (value) => ({ __op: "increment", value: Number(value || 0) }),
  arrayUnion: (...values) => ({ __op: "arrayUnion", values }),
  arrayRemove: (...values) => ({ __op: "arrayRemove", values }),
};

function isFieldValue(value) {
  return value && typeof value === "object" && typeof value.__op === "string";
}

function splitPath(path) {
  return String(path).split("/").filter(Boolean);
}

function collectionPathFromDocPath(path) {
  const parts = splitPath(path);
  return parts.slice(0, -1).join("/");
}

function docIdFromPath(path) {
  const parts = splitPath(path);
  return parts[parts.length - 1];
}

function getByPath(target, dottedPath) {
  return String(dottedPath)
    .split(".")
    .reduce((current, key) => (current && current[key] !== undefined ? current[key] : undefined), target);
}

function setByPath(target, dottedPath, value) {
  const keys = String(dottedPath).split(".");
  let current = target;
  keys.slice(0, -1).forEach((key) => {
    if (!current[key] || typeof current[key] !== "object" || Array.isArray(current[key])) {
      current[key] = {};
    }
    current = current[key];
  });
  current[keys[keys.length - 1]] = value;
}

function applyValue(currentValue, nextValue) {
  if (!isFieldValue(nextValue)) return nextValue;

  if (nextValue.__op === "serverTimestamp") {
    return new Date().toISOString();
  }

  if (nextValue.__op === "increment") {
    return Number(currentValue || 0) + nextValue.value;
  }

  if (nextValue.__op === "arrayUnion") {
    const current = Array.isArray(currentValue) ? currentValue : [];
    const serialized = new Set(current.map((item) => JSON.stringify(item)));
    const result = [...current];
    nextValue.values.forEach((item) => {
      const key = JSON.stringify(item);
      if (!serialized.has(key)) {
        serialized.add(key);
        result.push(item);
      }
    });
    return result;
  }

  if (nextValue.__op === "arrayRemove") {
    const removeSet = new Set(nextValue.values.map((item) => JSON.stringify(item)));
    return (Array.isArray(currentValue) ? currentValue : []).filter((item) => !removeSet.has(JSON.stringify(item)));
  }

  return nextValue;
}

function materializeData(input, existing = {}) {
  const output = { ...(existing || {}) };
  Object.entries(input || {}).forEach(([key, value]) => {
    const currentValue = getByPath(output, key);
    setByPath(output, key, applyValue(currentValue, value));
  });
  return output;
}

async function initPostgres() {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS app_documents (
      path TEXT PRIMARY KEY,
      collection_path TEXT NOT NULL,
      doc_id TEXT NOT NULL,
      data JSONB NOT NULL DEFAULT '{}'::jsonb,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    );
  `);
  await pool.query(`
    CREATE INDEX IF NOT EXISTS idx_app_documents_collection_path
      ON app_documents(collection_path);
  `);
}

class DocumentSnapshot {
  constructor(ref, row) {
    this.ref = ref;
    this.id = ref.id;
    this.exists = Boolean(row);
    this._data = row?.data || null;
  }

  data() {
    return this._data ? { ...this._data } : undefined;
  }
}

class QuerySnapshot {
  constructor(docs) {
    this.docs = docs;
    this.empty = docs.length === 0;
    this.size = docs.length;
  }
}

class DocumentReference {
  constructor(db, path) {
    this.db = db;
    this.path = path;
    this.id = docIdFromPath(path);
  }

  collection(name) {
    return new CollectionReference(this.db, `${this.path}/${name}`);
  }

  async get(client) {
    const executor = client || pool;
    const result = await executor.query("SELECT data FROM app_documents WHERE path = $1", [this.path]);
    return new DocumentSnapshot(this, result.rows[0] || null);
  }

  async set(data, options = {}, client) {
    const executor = client || pool;
    const existingSnap = options.merge ? await this.get(executor) : null;
    const existing = existingSnap?.exists ? existingSnap.data() : {};
    const nextData = options.merge ? materializeData(data, existing) : materializeData(data, {});

    await executor.query(
      `
        INSERT INTO app_documents(path, collection_path, doc_id, data)
        VALUES ($1, $2, $3, $4::jsonb)
        ON CONFLICT (path) DO UPDATE
        SET data = EXCLUDED.data, updated_at = NOW()
      `,
      [this.path, collectionPathFromDocPath(this.path), this.id, JSON.stringify(nextData)]
    );
  }

  async update(data, client) {
    const snap = await this.get(client);
    if (!snap.exists) {
      throw new Error(`Document not found: ${this.path}`);
    }
    await this.set(materializeData(data, snap.data()), {}, client);
  }
}

class Query {
  constructor(collectionRef, filters = []) {
    this.collectionRef = collectionRef;
    this.filters = filters;
  }

  where(field, operator, value) {
    return new Query(this.collectionRef, [...this.filters, { field, operator, value }]);
  }

  async get(client) {
    const snapshot = await this.collectionRef.get(client);
    const docs = snapshot.docs.filter((doc) => {
      const data = doc.data() || {};
      return this.filters.every(({ field, operator, value }) => {
        if (operator !== "==") {
          throw new Error(`Unsupported Postgres adapter query operator: ${operator}`);
        }
        return getByPath(data, field) === value;
      });
    });
    return new QuerySnapshot(docs);
  }
}

class CollectionReference {
  constructor(db, path) {
    this.db = db;
    this.path = path;
    this.id = splitPath(path).slice(-1)[0];
  }

  doc(id) {
    return new DocumentReference(this.db, `${this.path}/${id}`);
  }

  async add(data) {
    const id = crypto.randomUUID();
    const ref = this.doc(id);
    await ref.set(data);
    return ref;
  }

  where(field, operator, value) {
    return new Query(this, [{ field, operator, value }]);
  }

  async get(client) {
    const executor = client || pool;
    const result = await executor.query(
      "SELECT path, data FROM app_documents WHERE collection_path = $1 ORDER BY created_at ASC",
      [this.path]
    );
    return new QuerySnapshot(
      result.rows.map((row) => new DocumentSnapshot(this.doc(docIdFromPath(row.path)), row))
    );
  }
}

class WriteBatch {
  constructor(db) {
    this.db = db;
    this.operations = [];
  }

  set(ref, data, options) {
    this.operations.push({ type: "set", ref, data, options });
  }

  update(ref, data) {
    this.operations.push({ type: "update", ref, data });
  }

  async commit() {
    return this.db.runTransaction(async (tx) => {
      for (const operation of this.operations) {
        if (operation.type === "set") {
          await tx.set(operation.ref, operation.data, operation.options);
        } else if (operation.type === "update") {
          await tx.update(operation.ref, operation.data);
        }
      }
    });
  }
}

const db = {
  FieldValue,
  async init() {
    await initPostgres();
  },
  collection(name) {
    return new CollectionReference(this, String(name));
  },
  batch() {
    return new WriteBatch(this);
  },
  async runTransaction(callback) {
    const client = await pool.connect();
    try {
      await client.query("BEGIN");
      const tx = {
        get: (ref) => ref.get(client),
        set: (ref, data, options) => ref.set(data, options, client),
        update: (ref, data) => ref.update(data, client),
      };
      const result = await callback(tx);
      await client.query("COMMIT");
      return result;
    } catch (error) {
      await client.query("ROLLBACK");
      throw error;
    } finally {
      client.release();
    }
  },
  async listCollections() {
    const result = await pool.query("SELECT DISTINCT split_part(collection_path, '/', 1) AS id FROM app_documents");
    return result.rows.map((row) => ({ id: row.id }));
  },
  async query(text, params) {
    return pool.query(text, params);
  },
  async close() {
    await pool.end();
  },
};

module.exports = db;
